def project():
    choice=True
    while choice==True:
        import MAINLOOP
        MAINLOOP.MAIN()
project()

